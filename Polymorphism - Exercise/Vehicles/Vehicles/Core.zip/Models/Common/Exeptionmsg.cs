﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models.Common
{
    public static class Exeptionmsg
    {
        public static string EXP_MSG = "{0} needs refueling";
    }
}
