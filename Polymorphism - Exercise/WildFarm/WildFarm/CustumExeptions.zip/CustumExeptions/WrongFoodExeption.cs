﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.CustumExeptions
{
    public static class WrongFoodExeption
    {
        public static string Exp_Msg = "{0} does not eat {1}!";
       
    }
}
